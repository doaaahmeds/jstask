function hello() {
 console.log("hello world !");
    
}
export default hello