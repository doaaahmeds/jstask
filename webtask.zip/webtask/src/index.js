import hello from "./hello world"
hello()
import "./component/header/header"
import "./component/cover/cover"
import "./component/bio/bio"





