const gulp = require("gulp");
const { src, dest} = require("gulp")
const htmlmin = require('gulp-htmlmin');
const concat = require('gulp-concat');
var cleanCss = require('gulp-clean-css');
const terser = require('gulp-terser');
const imagemin = require('gulp-imagemin');

var replace = require('gulp-replace-path');
var path = require('path');
var globs={
    html:"project/*.html",
    css:"project/css/**/*.css",
    js:'project/js/**/*.js',
    img:'project/pics/*',
  }
function htmlgulp(){
    return src(globs.html).pipe(htmlmin({collapseWhitespace:true,removeComments:true}))
    .pipe(dest("dist"));
}
exports.html = htmlgulp


function cssgulp(){
    return src(globs.css)
    .pipe(concat("style.main.css"))
    .pipe(cleanCss())
    .pipe(dest(("dist/assets")))
}

exports.css = cssgulp
function jsgulp(){
    return src(globs.js)
    .pipe(concat("script.main.js"))
    .pipe(terser())
    .pipe(dest(("dist/assets")))
}
exports.js = jsgulp



function imggulp() {
    return gulp.src(globs.img)
        .pipe(imagemin())
        .pipe(gulp.dest('dist/images'));
}

exports.img = imggulp