

describe('Counter Component for lab', () => {

  it("when click btn fires increse fun should the interpolation detect the change",()=>{
   
  })
});
